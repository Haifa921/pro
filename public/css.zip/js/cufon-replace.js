Cufon.replace('.menu li a, h3, h4, .support, h1 a, .button, .button-2', { fontFamily: 'NewsGoth BT', hover:true });
